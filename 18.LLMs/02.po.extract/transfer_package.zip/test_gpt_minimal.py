import os
from openai import OpenAI
from dotenv import load_dotenv

def test_gpt():
    # Disable SSL warnings
    import urllib3
    urllib3.disable_warnings()
    
    # Set proxy settings
    os.environ['HTTP_PROXY'] = 'http://proxy.rme.com:8080'
    os.environ['HTTPS_PROXY'] = 'http://proxy.rme.com:8080'
    os.environ['REQUESTS_CA_BUNDLE'] = ''  # Disable SSL cert verification
    
    # Load API key
    load_dotenv()
    api_key = os.getenv('OPENAI_API_KEY')
    
    if not api_key:
        print("No API key found in .env file")
        return
        
    print(f"API key loaded (starts with: {api_key[:4]})")
    
    try:
        # Create httpx client with SSL verification disabled
        import httpx
        http_client = httpx.Client(
            verify=False,
            proxy='http://proxy.rme.com:8080'
        )
        
        # Create OpenAI client with custom http client
        client = OpenAI(
            api_key=api_key,
            timeout=10.0,
            http_client=http_client
        )
        
        print("\nTesting API with simple message...")
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Say hi"}],
            max_tokens=10  # Keep it very short
        )
        
        print(f"\nResponse received: {response.choices[0].message.content}")
        print("API connection successful!")
        
    except Exception as e:
        print(f"\nError: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_gpt()

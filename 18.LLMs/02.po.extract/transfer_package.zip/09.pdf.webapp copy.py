from flask import Flask, render_template, request, jsonify, session
import mysql.connector
from mysql.connector import Error
import os
import openai
import re
import socket
import tiktoken

# Configure OpenAI API
openai.api_key = "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"

# Database configuration
DB_CONFIG = {
    'host': '10.10.11.242',
    'user': 'omar2',
    'password': 'Omar_54321',
    'database': 'RME_TEST'
}

app = Flask(__name__)
app.secret_key = 'rme_document_ocr_chatbot_secret_key'

def get_db_connection():
    """Establish connection to MySQL database"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as e:
        print(f"Error connecting to MySQL database: {e}")
        return None

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/get_projects')
def get_projects():
    """Get all project names for dropdown"""
    connection = get_db_connection()
    if not connection:
        return jsonify([])
    
    cursor = connection.cursor()
    
    try:
        # Get distinct project names
        cursor.execute("SELECT DISTINCT project_name FROM `po.pdfs` WHERE project_name IS NOT NULL ORDER BY project_name")
        projects = [row[0] for row in cursor.fetchall()]
        return jsonify(projects)
    except Error as e:
        print(f"Error getting projects: {e}")
        return jsonify([])
    finally:
        cursor.close()
        connection.close()

@app.route('/get_document_types')
def get_document_types():
    """Get all document types for dropdown"""
    connection = get_db_connection()
    if not connection:
        return jsonify([])
    
    cursor = connection.cursor()
    
    try:
        # Get distinct document types
        cursor.execute("SELECT DISTINCT document_type FROM `po.pdfs` WHERE document_type IS NOT NULL ORDER BY document_type")
        doc_types = [row[0] for row in cursor.fetchall()]
        return jsonify(doc_types)
    finally:
        cursor.close()
        connection.close()

@app.route('/search_projects')
def search_projects():
    """Search for projects containing the search term"""
    search_term = request.args.get('term', '')
    
    if not search_term:
        return jsonify([])
    
    connection = get_db_connection()
    if not connection:
        return jsonify([])
    
    cursor = connection.cursor()
    
    try:
        # Search for projects containing the search term
        cursor.execute(
            "SELECT DISTINCT project_name FROM `po.pdfs` WHERE project_name LIKE %s ORDER BY project_name LIMIT 10",
            (f"%{search_term}%",)
        )
        projects = [row[0] for row in cursor.fetchall()]
        return jsonify(projects)
    except Error as e:
        print(f"Error searching projects: {e}")
        return jsonify([])
    finally:
        cursor.close()
        connection.close()

@app.route('/search_pdfs', methods=['POST'])
def search_pdfs():
    """Search for PDFs based on project name and document type"""
    project_name = request.form.get('project_name', '')
    document_type = request.form.get('document_type', '')
    
    if not project_name and not document_type:
        return jsonify({"error": "Please select a project name or document type"})
    
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        # Build query based on selected filters
        query = "SELECT id, pdf_filename, project_name, document_type FROM `po.pdfs` WHERE 1=1"
        params = []
        
        if project_name:
            query += " AND project_name = %s"
            params.append(project_name)
        
        if document_type:
            query += " AND document_type = %s"
            params.append(document_type)
        
        query += " ORDER BY pdf_filename LIMIT 100"
        
        cursor.execute(query, params)
        pdfs = cursor.fetchall()
        
        return jsonify({"pdfs": pdfs})
    except Error as e:
        print(f"Error searching PDFs: {e}")
        return jsonify({"error": f"Database error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

@app.route('/get_pdf_text/<int:pdf_id>')
def get_pdf_text(pdf_id):
    """Get the extracted text for a PDF"""
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        cursor.execute(
            "SELECT pdf_filename, extracted_text FROM `po.pdfs` WHERE id = %s",
            (pdf_id,)
        )
        pdf = cursor.fetchone()
        
        if not pdf:
            return jsonify({"error": "PDF not found"})
        
        return jsonify({
            "filename": pdf['pdf_filename'],
            "text": pdf['extracted_text']
        })
    except Error as e:
        print(f"Error getting PDF text: {e}")
        return jsonify({"error": f"Database error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

def num_tokens_from_string(string, model="gpt-4"):
    """Returns the number of tokens in a text string."""
    encoding = tiktoken.encoding_for_model(model)
    num_tokens = len(encoding.encode(string))
    return num_tokens

def split_text_into_chunks(text, max_tokens=6000, model="gpt-4"):
    """Split text into chunks of max_tokens."""
    encoding = tiktoken.encoding_for_model(model)
    tokens = encoding.encode(text)
    
    chunks = []
    current_chunk = []
    current_count = 0
    
    for token in tokens:
        if current_count >= max_tokens:
            chunks.append(encoding.decode(current_chunk))
            current_chunk = [token]
            current_count = 1
        else:
            current_chunk.append(token)
            current_count += 1
    
    if current_chunk:
        chunks.append(encoding.decode(current_chunk))
    
    return chunks

@app.route('/ask_ai', methods=['POST'])
def ask_ai():
    """Ask a question about a PDF using OpenAI API"""
    pdf_id = request.form.get('pdf_id')
    question = request.form.get('question')
    
    if not pdf_id or not question:
        return jsonify({"error": "PDF ID and question are required"})
    
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        cursor.execute(
            "SELECT pdf_filename, extracted_text FROM `po.pdfs` WHERE id = %s",
            (pdf_id,)
        )
        pdf = cursor.fetchone()
        
        if not pdf or not pdf['extracted_text']:
            return jsonify({"error": "PDF text not found"})
        
        # Prepare context for OpenAI
        full_context = pdf['extracted_text']
        model = "gpt-4"
        
        # Check token count of the full document
        token_count = num_tokens_from_string(full_context, model)
        warning_message = ""
        
        # Strategy based on token count
        if token_count <= 6000:
            # Document fits within token limit - use entire document
            context = full_context
            chunks = [context]
        elif token_count <= 12000:
            # Document can be split into two chunks
            chunks = split_text_into_chunks(full_context, max_tokens=6000, model=model)
            context = chunks[0]  # Start with first chunk
        else:
            # Document is very large - use only first 12000 tokens (2 chunks)
            chunks = split_text_into_chunks(full_context, max_tokens=6000, model=model)[:2]
            context = chunks[0]  # Start with first chunk
            warning_message = "Note: This document is very large. Only the first portion was used to answer your question."
        
        # Create system message - keep it short to save tokens
        system_message = "Answer questions based on document content only."
        
        # Create initial prompt - more concise to save tokens
        prompt = f"Document: {pdf['pdf_filename']}\n\nContent: {context}\n\nQuestion: {question}\n\nAnswer based only on the document content."
        
        # Call OpenAI API with first chunk
        response = openai.ChatCompletion.create(
            model=model,
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.3
        )
        
        answer = response.choices[0].message.content
        
        # If we have a second chunk and the answer is uncertain, try with the second chunk
        if len(chunks) > 1 and ("cannot be found" in answer.lower() or "don't have enough information" in answer.lower()):
            second_prompt = f"Document: {pdf['pdf_filename']} (continued)\n\nContent: {chunks[1]}\n\nQuestion: {question}\n\nAnswer based only on the document content."
            
            # Call OpenAI API with second chunk
            second_response = openai.ChatCompletion.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": second_prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            second_answer = second_response.choices[0].message.content
            
            # If second chunk has a more definitive answer, use it
            if "cannot be found" not in second_answer.lower() and "don't have enough information" not in second_answer.lower():
                answer = second_answer
        
        # Add warning if needed
        if warning_message:
            answer = f"{warning_message}\n\n{answer}"
        
        return jsonify({
            "filename": pdf['pdf_filename'],
            "answer": answer,
            "token_count": token_count
        })
    except Exception as e:
        print(f"Error asking AI: {e}")
        return jsonify({"error": f"AI error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

@app.route('/get_pdf_chunks/<int:pdf_id>')
def get_pdf_chunks(pdf_id):
    """Get the text chunks for a PDF"""
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        cursor.execute(
            """
            SELECT c.chunk_number, c.chunk_text 
            FROM `po.pdf_chunks` c
            WHERE c.pdf_id = %s
            ORDER BY c.chunk_number
            """,
            (pdf_id,)
        )
        chunks = cursor.fetchall()
        
        if not chunks:
            return jsonify({"error": "No chunks found for this PDF"})
        
        return jsonify({
            "chunks": chunks
        })
    except Error as e:
        print(f"Error getting PDF chunks: {e}")
        return jsonify({"error": f"Database error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

if __name__ == '__main__':
    # Get the hostname and IP address for display purposes
    hostname = socket.gethostname()
    try:
        # Get the local IP address that other computers on the network can use
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip_address = s.getsockname()[0]
        s.close()
    except:
        ip_address = '127.0.0.1'
    
    print(f"\n\n===================================================")
    print(f"RME Document OCR And Chat Bot")
    print(f"===================================================")
    print(f"Server running on: {hostname}")
    print(f"Access locally via: http://127.0.0.1:3000")
    print(f"Access from network via: http://{ip_address}:3000")
    print(f"===================================================")
    
    # Run the app on all network interfaces
    app.run(debug=True, host='0.0.0.0', port=3000)

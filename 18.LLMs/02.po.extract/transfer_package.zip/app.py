from flask import Flask, render_template, request, jsonify, session
import mysql.connector
from mysql.connector import Error
import os
import openai
from dotenv import load_dotenv
import re

# Load environment variables
load_dotenv()

# Configure OpenAI API
openai.api_key = "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"

# Database configuration
DB_CONFIG = {
    'host': '10.10.11.242',
    'user': 'omar2',
    'password': 'Omar_54321',
    'database': 'RME_TEST'
}

app = Flask(__name__)
app.secret_key = 'rme_document_ocr_chatbot_secret_key'

def get_db_connection():
    """Establish connection to MySQL database"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as e:
        print(f"Error connecting to MySQL database: {e}")
        return None

@app.route('/')
def index():
    """Render the main page"""
    return render_template('index.html')

@app.route('/get_projects')
def get_projects():
    """Get all project names for dropdown"""
    connection = get_db_connection()
    if not connection:
        return jsonify([])
    
    cursor = connection.cursor()
    
    try:
        # Get distinct project names
        cursor.execute("SELECT DISTINCT project_name FROM `po.pdfs` WHERE project_name IS NOT NULL ORDER BY project_name")
        projects = [row[0] for row in cursor.fetchall()]
        return jsonify(projects)
    except Error as e:
        print(f"Error getting projects: {e}")
        return jsonify([])
    finally:
        cursor.close()
        connection.close()

@app.route('/get_document_types')
def get_document_types():
    """Get all document types for dropdown"""
    connection = get_db_connection()
    if not connection:
        return jsonify([])
    
    cursor = connection.cursor()
    
    try:
        # Get distinct document types
        cursor.execute("SELECT DISTINCT document_type FROM `po.pdfs` WHERE document_type IS NOT NULL ORDER BY document_type")
        doc_types = [row[0] for row in cursor.fetchall()]
        return jsonify(doc_types)
    finally:
        cursor.close()
        connection.close()

@app.route('/search_projects')
def search_projects():
    """Search for projects containing the search term"""
    search_term = request.args.get('term', '')
    
    if not search_term:
        return jsonify([])
    
    connection = get_db_connection()
    if not connection:
        return jsonify([])
    
    cursor = connection.cursor()
    
    try:
        # Search for projects containing the search term
        cursor.execute(
            "SELECT DISTINCT project_name FROM `po.pdfs` WHERE project_name LIKE %s ORDER BY project_name LIMIT 10",
            (f"%{search_term}%",)
        )
        projects = [row[0] for row in cursor.fetchall()]
        return jsonify(projects)
    except Error as e:
        print(f"Error searching projects: {e}")
        return jsonify([])
    finally:
        cursor.close()
        connection.close()

@app.route('/search_pdfs', methods=['POST'])
def search_pdfs():
    """Search for PDFs based on project name and document type"""
    project_name = request.form.get('project_name', '')
    document_type = request.form.get('document_type', '')
    
    if not project_name and not document_type:
        return jsonify({"error": "Please select a project name or document type"})
    
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        # Build query based on selected filters
        query = "SELECT id, pdf_filename, project_name, document_type FROM `po.pdfs` WHERE 1=1"
        params = []
        
        if project_name:
            query += " AND project_name = %s"
            params.append(project_name)
        
        if document_type:
            query += " AND document_type = %s"
            params.append(document_type)
        
        query += " ORDER BY pdf_filename LIMIT 100"
        
        cursor.execute(query, params)
        pdfs = cursor.fetchall()
        
        return jsonify({"pdfs": pdfs})
    except Error as e:
        print(f"Error searching PDFs: {e}")
        return jsonify({"error": f"Database error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

@app.route('/get_pdf_text/<int:pdf_id>')
def get_pdf_text(pdf_id):
    """Get the extracted text for a PDF"""
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        cursor.execute(
            "SELECT pdf_filename, extracted_text FROM `po.pdfs` WHERE id = %s",
            (pdf_id,)
        )
        pdf = cursor.fetchone()
        
        if not pdf:
            return jsonify({"error": "PDF not found"})
        
        return jsonify({
            "filename": pdf['pdf_filename'],
            "text": pdf['extracted_text']
        })
    except Error as e:
        print(f"Error getting PDF text: {e}")
        return jsonify({"error": f"Database error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

@app.route('/ask_ai', methods=['POST'])
def ask_ai():
    """Ask a question about a PDF using OpenAI API"""
    pdf_id = request.form.get('pdf_id')
    question = request.form.get('question')
    
    if not pdf_id or not question:
        return jsonify({"error": "PDF ID and question are required"})
    
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        cursor.execute(
            "SELECT pdf_filename, extracted_text FROM `po.pdfs` WHERE id = %s",
            (pdf_id,)
        )
        pdf = cursor.fetchone()
        
        if not pdf or not pdf['extracted_text']:
            return jsonify({"error": "PDF text not found"})
        
        # Prepare context for OpenAI
        context = pdf['extracted_text']
        
        # Truncate context if too long (OpenAI has token limits)
        if len(context) > 15000:
            context = context[:15000] + "..."
        
        # Create prompt for OpenAI
        prompt = f"""
        Document: {pdf['pdf_filename']}
        
        Document Content:
        {context}
        
        Question: {question}
        
        Please answer the question based only on the information provided in the document above.
        If the answer cannot be found in the document, please state that clearly.
        """
        
        # Call OpenAI API
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that answers questions based on document content."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=1000,
            temperature=0.3
        )
        
        answer = response.choices[0].message.content
        
        return jsonify({
            "filename": pdf['pdf_filename'],
            "answer": answer
        })
    except Exception as e:
        print(f"Error asking AI: {e}")
        return jsonify({"error": f"AI error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

@app.route('/get_pdf_chunks/<int:pdf_id>')
def get_pdf_chunks(pdf_id):
    """Get the text chunks for a PDF"""
    connection = get_db_connection()
    if not connection:
        return jsonify({"error": "Database connection error"})
    
    cursor = connection.cursor(dictionary=True)
    
    try:
        cursor.execute(
            """
            SELECT c.chunk_number, c.chunk_text 
            FROM `po.pdf_chunks` c
            WHERE c.pdf_id = %s
            ORDER BY c.chunk_number
            """,
            (pdf_id,)
        )
        chunks = cursor.fetchall()
        
        if not chunks:
            return jsonify({"error": "No chunks found for this PDF"})
        
        return jsonify({
            "chunks": chunks
        })
    except Error as e:
        print(f"Error getting PDF chunks: {e}")
        return jsonify({"error": f"Database error: {str(e)}"})
    finally:
        cursor.close()
        connection.close()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)

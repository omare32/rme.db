import os
import openai
import mysql.connector
from mysql.connector import Error

# OpenAI API key
OPENAI_API_KEY = "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"

def get_db_connection():
    """Get MySQL database connection"""
    try:
        connection = mysql.connector.connect(
            host='10.10.11.242',
            user='omar2',
            password='Omar_54321',
            database='RME_TEST'
        )
        return connection
    except Error as e:
        print(f"Error connecting to database: {e}")
        return None

def get_table_schema():
    """Get schema of RME_PO_Follow_Up_Report table"""
    connection = get_db_connection()
    if not connection:
        return "Error connecting to database"
    
    try:
        cursor = connection.cursor()
        cursor.execute("DESCRIBE RME_PO_Follow_Up_Report")
        columns = cursor.fetchall()
        
        schema = "Table: RME_PO_Follow_Up_Report\nColumns:\n"
        for col in columns:
            schema += f"- {col[0]} ({col[1]})\n"
        
        return schema
    except Error as e:
        return f"Error getting schema: {e}"
    finally:
        cursor.close()
        connection.close()

def test_query_generation():
    """Test GPT query generation with a specific question"""
    # Set up OpenAI
    openai.api_key = OPENAI_API_KEY
    
    # Get schema
    schema = get_table_schema()
    print("\nSchema:")
    print(schema)
    
    # Question to test
    question = "what's the total amount of all pos in the last 3 days?"
    
    # Generate query
    prompt = f"""Given this database schema:
{schema}

Convert this question into a MySQL query:
"{question}"

Rules:
1. Only use columns from the schema above
2. Return ONLY the SQL query, nothing else
3. Use proper MySQL syntax
4. Add helpful comments
"""
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a SQL query generator. Only output the SQL query, nothing else."},
                {"role": "user", "content": prompt}
            ],
            temperature=0
        )
        
        query = response.choices[0].message.content.strip()
        print("\nGenerated Query:")
        print(query)
        
        # Test the query
        connection = get_db_connection()
        if connection:
            try:
                cursor = connection.cursor()
                cursor.execute(query)
                results = cursor.fetchall()
                print("\nQuery Results:")
                for row in results:
                    print(row)
            except Error as e:
                print(f"\nError executing query: {e}")
            finally:
                cursor.close()
                connection.close()
                
    except Exception as e:
        print(f"\nError generating query: {e}")

if __name__ == "__main__":
    test_query_generation()
